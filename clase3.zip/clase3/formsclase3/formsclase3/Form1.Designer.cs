﻿namespace formsclase3
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_legajo = new System.Windows.Forms.Label();
            this.label_nombre = new System.Windows.Forms.Label();
            this.txt_legajo = new System.Windows.Forms.TextBox();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.btn_agregar = new System.Windows.Forms.Button();
            this.grid_personas = new System.Windows.Forms.DataGridView();
            this.combo1 = new System.Windows.Forms.ComboBox();
            this.list1 = new System.Windows.Forms.ListBox();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.btn_borrar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grid_personas)).BeginInit();
            this.SuspendLayout();
            // 
            // label_legajo
            // 
            this.label_legajo.AutoSize = true;
            this.label_legajo.Location = new System.Drawing.Point(10, 9);
            this.label_legajo.Name = "label_legajo";
            this.label_legajo.Size = new System.Drawing.Size(39, 13);
            this.label_legajo.TabIndex = 0;
            this.label_legajo.Text = "Legajo";
            // 
            // label_nombre
            // 
            this.label_nombre.AutoSize = true;
            this.label_nombre.Location = new System.Drawing.Point(10, 43);
            this.label_nombre.Name = "label_nombre";
            this.label_nombre.Size = new System.Drawing.Size(44, 13);
            this.label_nombre.TabIndex = 1;
            this.label_nombre.Text = "Nombre";
            // 
            // txt_legajo
            // 
            this.txt_legajo.Location = new System.Drawing.Point(55, 6);
            this.txt_legajo.Name = "txt_legajo";
            this.txt_legajo.Size = new System.Drawing.Size(112, 20);
            this.txt_legajo.TabIndex = 2;
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(55, 40);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(112, 20);
            this.txt_nombre.TabIndex = 3;
            // 
            // btn_agregar
            // 
            this.btn_agregar.Location = new System.Drawing.Point(173, 6);
            this.btn_agregar.Name = "btn_agregar";
            this.btn_agregar.Size = new System.Drawing.Size(87, 54);
            this.btn_agregar.TabIndex = 4;
            this.btn_agregar.Text = "Agregar";
            this.btn_agregar.UseVisualStyleBackColor = true;
            this.btn_agregar.Click += new System.EventHandler(this.btn_agregar_Click);
            // 
            // grid_personas
            // 
            this.grid_personas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_personas.Location = new System.Drawing.Point(13, 66);
            this.grid_personas.Name = "grid_personas";
            this.grid_personas.Size = new System.Drawing.Size(400, 372);
            this.grid_personas.TabIndex = 5;
            this.grid_personas.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_personas_CellClick);
            // 
            // combo1
            // 
            this.combo1.FormattingEnabled = true;
            this.combo1.Location = new System.Drawing.Point(419, 126);
            this.combo1.Name = "combo1";
            this.combo1.Size = new System.Drawing.Size(166, 21);
            this.combo1.TabIndex = 6;
            // 
            // list1
            // 
            this.list1.FormattingEnabled = true;
            this.list1.Location = new System.Drawing.Point(419, 153);
            this.list1.Name = "list1";
            this.list1.Size = new System.Drawing.Size(165, 212);
            this.list1.TabIndex = 7;
            // 
            // btn_modificar
            // 
            this.btn_modificar.Location = new System.Drawing.Point(266, 6);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(87, 54);
            this.btn_modificar.TabIndex = 8;
            this.btn_modificar.Text = "Modificar";
            this.btn_modificar.UseVisualStyleBackColor = true;
            this.btn_modificar.Click += new System.EventHandler(this.btn_modificar_Click);
            // 
            // btn_borrar
            // 
            this.btn_borrar.Location = new System.Drawing.Point(359, 6);
            this.btn_borrar.Name = "btn_borrar";
            this.btn_borrar.Size = new System.Drawing.Size(87, 54);
            this.btn_borrar.TabIndex = 9;
            this.btn_borrar.Text = "Borrar";
            this.btn_borrar.UseVisualStyleBackColor = true;
            this.btn_borrar.Click += new System.EventHandler(this.btn_borrar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 450);
            this.Controls.Add(this.btn_borrar);
            this.Controls.Add(this.btn_modificar);
            this.Controls.Add(this.list1);
            this.Controls.Add(this.combo1);
            this.Controls.Add(this.grid_personas);
            this.Controls.Add(this.btn_agregar);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.txt_legajo);
            this.Controls.Add(this.label_nombre);
            this.Controls.Add(this.label_legajo);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.grid_personas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_legajo;
        private System.Windows.Forms.Label label_nombre;
        private System.Windows.Forms.TextBox txt_legajo;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Button btn_agregar;
        private System.Windows.Forms.DataGridView grid_personas;
        private System.Windows.Forms.ComboBox combo1;
        private System.Windows.Forms.ListBox list1;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.Button btn_borrar;
    }
}

