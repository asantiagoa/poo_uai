﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace formsclase3
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //List<Persona> listaPer = new List<Persona>();

        Facultad facu = new Facultad();

        private void btn_agregar_Click(object sender, EventArgs e)
        {
            facu.agregar(txt_legajo.Text, txt_nombre.Text);
            facu.Mostrar(facu.ListaPer, grid_personas);
        }


        private void grid_personas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            /*temp = (Persona)grid_personas.Rows[e.RowIndex].DataBoundItem;
            txt_legajo.Text = temp.Legajo.ToString();
            txt_nombre.Text = temp.Nombre;*/
        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {

            //temp = listaPer.Find(listaPer => listaPer.Nombre == txt_nombre.Text);

            /*temp.Legajo = Convert.ToInt32(txt_legajo.Text);
            temp.Nombre = txt_nombre.Text;

            grid_personas.DataSource = null;
            grid_personas.DataSource = listaPer;*/
        }

        private void btn_borrar_Click(object sender, EventArgs e)
        {

            /*foreach (var item in listaPer)
            {
                if (item.Legajo == Convert.ToInt32(txt_legajo.Text) && item.Nombre == txt_nombre.Text)
                {
                    //temp = item;
                    listaPer.Remove(item);
                }
            }*/

            /*listaPer.Remove(listaPer.Find(listaPer => listaPer.Nombre == txt_nombre.Text));
            grid_personas.DataSource = null;
            grid_personas.DataSource = listaPer;*/
        }
    }
}
