﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//aca va la lista de personas y los metodos de borrar(per) editar(per) eliminar(per) mostrar(lista) etc
namespace formsclase3
{
    class Facultad
    {
        //List<Persona> listaPer = new List<Persona>();
        private List<Persona> listaPer = new List<Persona> ();

        public List<Persona> ListaPer
        {
            get { return listaPer; }
            set { listaPer = value; }
        }


        public void agregar(/*Persona per,*/ string legajo, string nombre)
        {
            Persona per = new Persona();
            per.Legajo = Convert.ToInt32(legajo);
            per.Nombre = nombre;

            ListaPer.Add(per);
        }

        public void Modificar(Persona per)
        {
            //return per;
        }

        public void Eliminar(Persona per)
        {

        }

        public void Mostrar(List<Persona> listPer, DataGridView grid_personas)
        {
            grid_personas.DataSource = null;
            grid_personas.DataSource = listaPer;

            /*combo1.DataSource = null;
            combo1.DataSource = listaPer;
            combo1.DisplayMember = "Legajo";

            list1.DataSource = null;
            list1.DataSource = listaPer;
            list1.DisplayMember = "Nombre";*/
        }

        public void IncrementarLegajo()
        {

        }

        public void MinEdad()
        {

        }

        public void MaxEdad()
        {

        }

        public void PromedioEdad()
        {

        }

        public void CantPersonas()
        {

        }
    }
}
