﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nafta
{
    public class Surtidor
    {

		List<Venta> ventas = new List<Venta>();

		private int Id;

		public int id
		{
			get { return Id; }
			set { Id = value; }
		}

		private decimal litros;

		public decimal Litros
		{
			get { return litros; }
			set { litros = value; }
		}


	}
}
