﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nafta
{
    public class Estacion
    {
        Nafta normal = new ();
        Nafta super = new ();
        Nafta premium = new ();

        normal.Nombre = "test";

        List<Nafta> listaNaftas = new List<Nafta>();


    }
}
