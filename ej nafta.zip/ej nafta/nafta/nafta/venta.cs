﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nafta
{
    public class Venta
    {
		private int Id;

		public int id
		{
			get { return Id; }
			set { Id = value; }
		}

		private Nafta tipoNafta;

		public Nafta TipoNafta
		{
			get { return tipoNafta; }
			set { tipoNafta = value; }
		}

		private Surtidor surtidor;

		public Surtidor Surtidor
		{
			get { return surtidor; }
			set { surtidor = value; }
		}


		private decimal litros;

		public decimal Litros
		{
			get { return litros; }
			set { litros = value; }
		}
	}
}
