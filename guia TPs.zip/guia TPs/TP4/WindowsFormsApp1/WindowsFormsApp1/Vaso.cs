﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Vaso
    {
		private TipoVaso tVaso;

		public TipoVaso Tvaso
		{
			get { return tVaso; }
			set { tVaso = value; }
		}
			
		private Cerveza cerveza;

		public Cerveza Cerveza
		{
			get { return cerveza; }
			set { cerveza = value; }
		}

		private double precio;

		public double Precio
		{
			get { return precio; }
			set { precio = value; }
		}



		public Vaso(TipoVaso tipoVaso, Cerveza cerveza)
		{
			this.Tvaso = tipoVaso;
			this.Cerveza = cerveza;
			this.precio = this.CalcularPrecio();
		}

		public double getVol()
		{
			double vol;

			switch (this.tVaso)
			{
				case TipoVaso.Chopp:
					vol = 0.75;
					break;

				case TipoVaso.Jarra:
					vol = 3;
					break;

				case TipoVaso.Vaso:
					vol = 0.5;
					break;

				default:
					vol = 0;
					break;
			}
			return vol;
		}

        public double CalcularPrecio()
		{
			double precio;
			double vol;

			vol = this.getVol();

			precio = vol * this.Cerveza.ValorL;
			return precio;
		}

    }
}
