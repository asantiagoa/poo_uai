﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class Venta
    {
        List<Vaso> listaVasos;// = new List<Vaso>();

		private float total;

		public float Total
		{
			get { return total; }
			set { total = value; }
		}

		public Venta(List<Vaso> lvasos)
		{
			this.listaVasos = lvasos;
			float total;
			foreach(Vaso v in lvasos)
			{
				
			}
			//parcial hasta el 8 big 
			//this.total =
		}
	}
}
