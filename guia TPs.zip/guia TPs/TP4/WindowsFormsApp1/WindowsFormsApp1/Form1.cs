﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 
 EJERCICIO N°4

-cerveza
-vaso
-venta
-negocio

negocio-> lista de ventas
venta->lista de vasos

 */
namespace WindowsFormsApp1
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Negocio negocio = new Negocio();
            negocio.listaCervezas.Append(new Cerveza("Rubia Nacional", 70));
            negocio.listaCervezas.Append(new Cerveza("Negra Nacional", 88));
            negocio.listaCervezas.Append(new Cerveza("Rubia Extranjera", 95));
        }
    }
}
