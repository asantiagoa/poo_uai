﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Cerveza
    {
		private string nombre;

		public string Nombre
		{
			get { return nombre; }
			set { nombre = value; }
		}

		private double valorL;

		public double ValorL
		{
			get { return valorL; }
			set { valorL = value; }
		}


		public Cerveza(string nombre, double valorL)
		{
			this.Nombre = nombre;
			this.ValorL = valorL;
		}

	}
}
