﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clase2
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //instanciar
        Persona per = new Persona();
        Resumen res = new Resumen();

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btn_carga_Click(object sender, EventArgs e)
        {
            max.Text = res.CalcularMax(int.Parse(text_edad.Text)).ToString();
            min.Text = res.CalcularMin(int.Parse(text_edad.Text)).ToString();
            prom.Text = res.CalcularProm(int.Parse(text_edad.Text)).ToString();
        }
    }
}
