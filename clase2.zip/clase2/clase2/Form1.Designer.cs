﻿namespace clase2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_carga = new System.Windows.Forms.Button();
            this.label_max = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.prom = new System.Windows.Forms.Label();
            this.min = new System.Windows.Forms.Label();
            this.max = new System.Windows.Forms.Label();
            this.text_edad = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_carga
            // 
            this.btn_carga.Location = new System.Drawing.Point(12, 106);
            this.btn_carga.Name = "btn_carga";
            this.btn_carga.Size = new System.Drawing.Size(75, 23);
            this.btn_carga.TabIndex = 0;
            this.btn_carga.Text = "CARGAR";
            this.btn_carga.UseVisualStyleBackColor = true;
            this.btn_carga.Click += new System.EventHandler(this.btn_carga_Click);
            // 
            // label_max
            // 
            this.label_max.AutoSize = true;
            this.label_max.Location = new System.Drawing.Point(218, 66);
            this.label_max.Name = "label_max";
            this.label_max.Size = new System.Drawing.Size(30, 13);
            this.label_max.TabIndex = 1;
            this.label_max.Text = "MAX";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(218, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "MIN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(218, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "PROM";
            // 
            // prom
            // 
            this.prom.AutoSize = true;
            this.prom.Location = new System.Drawing.Point(259, 116);
            this.prom.Name = "prom";
            this.prom.Size = new System.Drawing.Size(13, 13);
            this.prom.TabIndex = 6;
            this.prom.Text = "0";
            // 
            // min
            // 
            this.min.AutoSize = true;
            this.min.Location = new System.Drawing.Point(259, 91);
            this.min.Name = "min";
            this.min.Size = new System.Drawing.Size(13, 13);
            this.min.TabIndex = 5;
            this.min.Text = "0";
            // 
            // max
            // 
            this.max.AutoSize = true;
            this.max.Location = new System.Drawing.Point(259, 66);
            this.max.Name = "max";
            this.max.Size = new System.Drawing.Size(13, 13);
            this.max.TabIndex = 4;
            this.max.Text = "0";
            // 
            // text_edad
            // 
            this.text_edad.Location = new System.Drawing.Point(13, 83);
            this.text_edad.Name = "text_edad";
            this.text_edad.Size = new System.Drawing.Size(100, 20);
            this.text_edad.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.text_edad);
            this.Controls.Add(this.prom);
            this.Controls.Add(this.min);
            this.Controls.Add(this.max);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_max);
            this.Controls.Add(this.btn_carga);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_carga;
        private System.Windows.Forms.Label label_max;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label prom;
        private System.Windows.Forms.Label min;
        private System.Windows.Forms.Label max;
        private System.Windows.Forms.TextBox text_edad;
    }
}

