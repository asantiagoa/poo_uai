﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase2
{
    class Resumen
    {

        private int cont;

        public int Cont
        {
            get { return cont; }
			set { cont = value; }
        }

        private int max;

		public int Max
		{
			get { return max; }
			set { max = value; }
		}

		private int min;

		public int Min
		{
			get { return min; }
			set { min = value; }
		}

		private int prom;

		public int Prom
		{
			get { return prom; }
			set { prom = value; }
		}

		public int CalcularMax(int num)
		{

			if (max < num){
				max = num;
			}
			return max;
		}

        public int CalcularMin(int num)
        {
            if (min > num || min == 0)
            {
                min = num;
            }
            return min;
        }

        public int CalcularProm(int num)
        {
			cont++;
			prom += num;
			prom = prom / cont;
			return prom;
        }


    }
}
